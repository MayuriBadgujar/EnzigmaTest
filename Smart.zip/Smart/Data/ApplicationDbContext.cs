﻿//namespace Smart.Data
//{
//    public class ApplicationDbContext
//    {

//    }
//}
using Microsoft.EntityFrameworkCore;
using Smart.Models;


public class ApplicationDbContext : DbContext
{
    public ApplicationDbContext(DbContextOptions<ApplicationDbContext> options)
        : base(options) { }

    public DbSet<TaskItem> Tasks { get; set; }
}