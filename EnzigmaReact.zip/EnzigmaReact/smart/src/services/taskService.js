// src/services/taskService.js
import axios from 'axios';

const API_BASE_URL = 'https://localhost:7066/api/TaskItems'; // Replace PORT with your backend port

export const getAllTasks = () => axios.get(API_BASE_URL);
export const createTask = (task) => axios.post(API_BASE_URL, task);
export const updateTask = (id, task) => axios.put(`${API_BASE_URL}/${id}`, task);
export const deleteTask = (id) => axios.delete(`${API_BASE_URL}/${id}`);
