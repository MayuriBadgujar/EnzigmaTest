// src/components/TaskManager.js
import React, { useState, useEffect } from 'react';
import {
  getAllTasks,
  createTask,
  updateTask,
  deleteTask,
} from '../services/taskService';
import './TaskManager.css';

function TaskManager() {
  const [tasks, setTasks] = useState([]);
  const [title, setTitle] = useState('');
  const [description, setDescription] = useState('');
  const [priority, setPriority] = useState('');
  const [dueDate, setDueDate] = useState('');
  const [editingId, setEditingId] = useState(null);

  useEffect(() => {
    loadTasks();
  }, []);

  const loadTasks = async () => {
    try {
      const response = await getAllTasks();
      setTasks(response.data);
    } catch (error) {
      console.error('Error fetching tasks:', error);
    }
  };

  const handleAddTask = async (e) => {
    e.preventDefault();
    try {
      const task = {
        title,
        description,
        priority,
        dueDate,
        completed: false,
      };
      if (editingId) {
        await updateTask(editingId, { ...task, id: editingId });
        setEditingId(null);
      } else {
        await createTask(task);
      }

      setTitle('');
      setDescription('');
      setPriority('');
      setDueDate('');
      loadTasks();
    } catch (error) {
      console.error('Error saving task:', error);
    }
  };

  const handleDeleteTask = async (id) => {
    try {
      await deleteTask(id);
      loadTasks();
    } catch (error) {
      console.error('Error deleting task:', error);
    }
  };

  const handleEditTask = (task) => {
    setTitle(task.title);
    setDescription(task.description);
    setPriority(task.priority);
    setDueDate(task.dueDate);
    setEditingId(task.id);
  };

  const handleToggleComplete = async (id) => {
    const updatedTask = tasks.find(task => task.id === id);
    try {
      await updateTask(id, { ...updatedTask, completed: !updatedTask.completed });
      loadTasks();
    } catch (error) {
      console.error('Error toggling task:', error);
    }
  };

  return (
    <div className="container">
      <h1>Smart Task Manager</h1>

      <form className="task-form" onSubmit={handleAddTask}>
        <input type="text" placeholder="Title" value={title} onChange={(e) => setTitle(e.target.value)} />
        <input type="text" placeholder="Description" value={description} onChange={(e) => setDescription(e.target.value)} />
        <select value={priority} onChange={(e) => setPriority(e.target.value)}>
          <option value="">Priority</option>
          <option value="High">High</option>
          <option value="Medium">Medium</option>
          <option value="Low">Low</option>
        </select>
        <input type="date" value={dueDate} onChange={(e) => setDueDate(e.target.value)} />
        <button type="submit">{editingId ? 'Update Task' : 'Add Task'}</button>
      </form>

      <table className="task-table">
        <thead>
          <tr>
            <th>Title</th>
            <th>Description</th>
            <th>Priority</th>
            <th>Due Date</th>
            <th>Status</th>
            <th>Actions</th>
          </tr>
        </thead>
        <tbody>
          {tasks.map(task => (
            <tr key={task.id} className={task.completed ? 'completed' : ''}>
              <td>{task.title}</td>
              <td>{task.description}</td>
              <td>{task.priority}</td>
              <td>{task.dueDate}</td>
              <td>{task.completed ? 'Done' : 'Pending'}</td>
              <td>
  <button className="btn-orange" onClick={() => handleEditTask(task)}>Edit</button>
  <button className="btn-yellow" onClick={() => handleToggleComplete(task.id)}>
    {task.completed ? 'Undo' : 'Mark Complete'}
  </button>
  <button className="btn-red" onClick={() => handleDeleteTask(task.id)}>Delete</button>
</td>

            </tr>
          ))}
        </tbody>
      </table>
    </div>
  );
}

export default TaskManager;
